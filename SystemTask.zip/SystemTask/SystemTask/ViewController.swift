//
//  ViewController.swift
//  SystemTask
//
//  Created by Veerendra on 28/06/20.
//  Copyright © 2020 Rose. All rights reserved.
//

import UIKit
import SwiftyJSON

class ViewController: UIViewController {

    //Mark: - outlets
    @IBOutlet weak var selectedLbl: UILabel!
    @IBOutlet weak var globalTable: UITableView!
    
    
    //Mark: - variables
    var ListArr: [Lists] = []
    var hawaiApiObject : HawaiApi = HawaiApi()
    var selectedToggleCount = 0
    var pullToRefresh = UIRefreshControl()
    //Mark: - Lifecycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        pullToRefresh.attributedTitle = NSAttributedString(string: "Fetch List")
        pullToRefresh.addTarget(self, action: #selector(self.refreshTableView(_:)), for: UIControl.Event.valueChanged)
        globalTable.addSubview(pullToRefresh)
    }

    override func viewWillAppear(_ animated: Bool) {
        getItemList()
    }
    
    //Mark: - Api Calls
    func getItemList() {
        ListArr.removeAll()
        hawaiApiObject.getList(paramValues: hawaiApiObject, success: { (response) in
         //   print(response)
            let metaObject = response["meta"].dictionaryValue
            let viewObject: JSON = JSON(metaObject["view"] as Any)
            let itemList = viewObject["columns"].arrayValue
//            print(itemList)
            for item in itemList {
                self.ListArr.append(Lists(item: ListItem(displayName: item["name"].stringValue, fieldName: item["fieldName"].stringValue, position: item["position"].stringValue, toggleStatus: "0")))
            }
            self.pullToRefresh.endRefreshing()
            self.globalTable.reloadData()
            self.selectedToggleCount = 0
            self.selectedLbl.text = "0"
        }) { error in
            print(error)
        }
    }
    
    //Mark: - Refresh tableView
    @objc func refreshTableView(_ sender: AnyObject) {
        getItemList()
    }

}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 120
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ListArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: ListCell = tableView.dequeueReusableCell(withIdentifier: "ListCell", for: indexPath) as! ListCell
        let columnObject = ListArr[indexPath.row].item
        cell.displayNameLbl.text = columnObject.displayName
        cell.fieldNameLbl.text = columnObject.fieldName
        cell.positionLbl.text = columnObject.position
        
        if columnObject.toggleStatus == "0" {
            cell.toggleSwitch.isOn = false
        }
        else {
            cell.toggleSwitch.isOn = true
        }
        cell.toggleSwitch.tag = indexPath.row
        cell.toggleSwitch.addTarget(self, action: #selector(self.selectToggle(_:)), for: UIControl.Event.valueChanged)
        return cell
    }
    
    @objc func selectToggle(_ sender: UISwitch) {
        var columnObject = ListArr[sender.tag].item
        if columnObject.toggleStatus == "0" {
            columnObject.toggleStatus = "1"
            selectedToggleCount += 1
        }
        else {
            columnObject.toggleStatus = "0"
            selectedToggleCount -= 1
        }
        ListArr[sender.tag].item = columnObject
        globalTable.reloadData()
        selectedLbl.text = "\(selectedToggleCount)"
        
    }
    
    
    
    
}

