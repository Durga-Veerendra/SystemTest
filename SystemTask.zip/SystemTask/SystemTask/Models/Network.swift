//
//  Network.swift
//  SystemTask
//
//  Created by Veerendra on 28/06/20.
//  Copyright © 2020 Rose. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON
import Reachability

class Network {
    static func process(_ request: HTTPMethod, url: String, headers: [String: String]?, params: Parameters, success: @escaping (_ JSON: JSON) -> (), failure: @escaping (_ error: apiFailureEnum) -> ()) {
        
        print("\(devBaseURL)\(url)")
        
        do {
            let reacher = try Reachability()
            var responsData = JSON()
            
            if reacher.connection == .unavailable {
                failure(.isNetworkError)
            }
            else {
                let url: URL = URL(string: "\(devBaseURL)\(url)")!
                let request = AF.request(url)
                request.responseJSON { response in
                    switch response.result {
                    case .success(let json):
                        print(response.response?.statusCode as Any)
                        if let statusCode = response.response?.statusCode, statusCode == 401 {
                            failure(.isApiError)
                        }
                        else if let statusCode = response.response?.statusCode, statusCode == 200 {
                            responsData = JSON(json);
                            success(responsData)
                        }
                        else {
                            failure(.isApiError)
                        }
                        
                    case .failure(let error):
                        print(error)
                        failure(.isApiError)
                    }
                }
            }
        }
        catch _ as NSError {
            
        }
        
    }
}
