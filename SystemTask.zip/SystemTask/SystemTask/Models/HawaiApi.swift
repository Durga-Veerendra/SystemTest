//
//  HawaiApi.swift
//  SystemTask
//
//  Created by Veerendra on 28/06/20.
//  Copyright © 2020 Rose. All rights reserved.
//

import Foundation
import SwiftyJSON

class HawaiApi {
    func getList(paramValues: HawaiApi, success: @escaping (_ responseJson: JSON) -> (), failure: @escaping(apiFailureEnum) -> ()) {
        Network.process(.post, url: "DOWNLOAD", headers: ["Authorization":""], params: ["String": "String"], success: { (response) in
            success(response)
            
        }) { error in
            failure(error)
        }
    }
}
