//
//  Constants.swift
//  SystemTask
//
//  Created by Veerendra on 28/06/20.
//  Copyright © 2020 Rose. All rights reserved.
//

import Foundation


public let devBaseURL = "https://data.hawaii.gov/api/views/usep-nua7/rows.json?accessType="

public enum apiFailureEnum : String {
    case isApiError
    case isNetworkError
    case isSessionExpired
}

//displaying the name, field_name, position
struct ListItem {
    var displayName : String
    var fieldName : String
    var position: String
    var toggleStatus: String
}

struct Lists {
    var item: ListItem
}


